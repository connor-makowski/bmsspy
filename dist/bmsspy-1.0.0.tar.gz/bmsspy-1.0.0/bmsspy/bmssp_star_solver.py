from heapq import heappush, heappop
from math import ceil, log

from bmsspy.bmssp_data_structure import BmsspDataStructure
from bmsspy.utils import inf


class BmsspStarSolver:
    def __init__(
        self,
        graph: list[dict[int, int | float]],
        origin_id: int,
        destination_id: int,
        heuristic_fn: callable,
    ):
        """
        Function:

        - Initialize the BMSSP solver with a graph represented as an adjacency list.

        Required Arguments:

        - graph:
            - Type: list[dict[int, int | float]]
            - Description: The graph is represented as an adjacency list, where each node points to a dictionary of its neighbors and their edge weights.
        - origin_id:
            - Type: int
            - What: The ID of the starting node for the BMSSP algorithm.
        - destination_id:
            - Type: int
            - What: The ID of the target node for the BMSSP* algorithm.
            - Note: This is used in conjunction with the heuristic function to guide the search.
        - heuristic_fn
            - Type: callable
            - What: A heuristic function that takes in two node ids and returns an estimated cost between them
            - Note: This function is used to guide the search towards the destination node
            - Note: This heuristic must be admissible (never overestimates the true cost) to guarantee optimality

        Optional Arguments:

        - None
        """
        self.graph = graph
        self.origin_id = origin_id
        self.destination_id = destination_id
        self.original_graph_length = len(graph)
        self.graph_length = len(self.graph)
        self.distance_matrix = [inf] * self.graph_length
        self.heuristic_distance_matrix = [inf] * self.graph_length
        self.predecessor = [-1] * self.graph_length
        self.distance_matrix[origin_id] = 0
        if heuristic_fn is None:
            raise ValueError(
                "A heuristic function must be provided for the BMSSP* solver"
            )
        self.heuristic_fn = heuristic_fn

        if self.graph_length <= 2:
            raise ValueError("Your provided graph must have more than 2 nodes")

        # Practical choices (k and t) based on n
        self.pivot_relaxation_steps = max(
            2, int(log(self.graph_length) ** (1 / 3.0))
        )  # k
        # Modification: Change int to ceil
        self.target_tree_depth = max(
            2, ceil(log(self.graph_length) ** (2 / 3.0))
        )  # t

        # Compute max_tree_depth based on k and t
        self.max_tree_depth = int(
            ceil(
                log(max(2, self.graph_length)) / max(1, self.target_tree_depth)
            )
        )

        # Run the solver algorithm
        upper_bound, frontier = self.recursive_bmssp(
            self.max_tree_depth, inf, {origin_id}
        )

    def find_pivots(
        self, upper_bound: int | float, frontier: set[int]
    ) -> tuple[set[int], set[int]]:
        """
        Function:

        - Finds pivot sets pivots and temp_frontier according to Algorithm 1.

        Required Arguments:

        - upper_bound:
            - Type: int | float
            - What: The upper bound threshold (B)
        - frontier:
            - Type: set[int]
            - What: Set of vertices (S)

        Optional Arguments:

        - None

        Returns:

        - pivots:
            - Type: Set[int]
            - What: Set of pivot vertices
        - frontier:
            - Type: Set[int]
            - What: Return a new frontier set of vertices within the upper_bound
        """
        temp_frontier = set(frontier)
        prev_frontier = set(frontier)

        # Multi-step limited relaxation from current frontier
        for _ in range(self.pivot_relaxation_steps):
            curr_frontier = set()
            for prev_frontier_idx in prev_frontier:
                prev_frontier_distance = self.distance_matrix[prev_frontier_idx]
                for connection_idx, connection_distance in self.graph[
                    prev_frontier_idx
                ].items():
                    new_distance = prev_frontier_distance + connection_distance
                    new_heuristic_distance = (
                        self.heuristic_fn(connection_idx, self.destination_id)
                        + new_distance
                    )
                    # Important: Allow equality on relaxations
                    if new_distance <= self.distance_matrix[connection_idx]:
                        # Addition: Add predecessor tracking
                        if new_distance < self.distance_matrix[connection_idx]:
                            self.predecessor[connection_idx] = prev_frontier_idx
                            self.distance_matrix[connection_idx] = new_distance
                        if new_distance < upper_bound:
                            curr_frontier.add(connection_idx)
            temp_frontier.update(curr_frontier)
            # If the search balloons, take the current frontier as pivots
            if len(temp_frontier) > self.pivot_relaxation_steps * len(frontier):
                pivots = set(frontier)
                return pivots, temp_frontier
            prev_frontier = curr_frontier

        # Build tight-edge forest F on temp_frontier: edges (u -> v) with db[u] + w == db[v]
        forest_adj = {i: set() for i in temp_frontier}
        indegree = {i: 0 for i in temp_frontier}
        for frontier_idx in temp_frontier:
            frontier_distance = self.distance_matrix[frontier_idx]
            for connection_idx, connection_distance in self.graph[
                frontier_idx
            ].items():
                if (
                    connection_idx in temp_frontier
                    and abs(
                        (frontier_distance + connection_distance)
                        - self.distance_matrix[connection_idx]
                    )
                    < 1e-12
                ):
                    # direction is frontier_idx -> connection_idx (parent to child)
                    forest_adj[frontier_idx].add(connection_idx)
                    indegree[connection_idx] += 1

        # Non-sticky DFS that counts size of the reachable tree
        def dfs_count(root):
            seen = set()
            stack = [root]
            cnt = 0
            while stack:
                x = stack.pop()
                if x in seen:
                    continue
                seen.add(x)
                cnt += 1
                stack.extend(forest_adj[x])
            return cnt

        pivots = set()
        for frontier_idx in frontier:
            if indegree.get(frontier_idx, 0) == 0:
                size = dfs_count(frontier_idx)
                if size >= self.pivot_relaxation_steps:
                    pivots.add(frontier_idx)

        return pivots, temp_frontier

    def base_case(
        self, upper_bound: int | float, frontier: set[int]
    ) -> tuple[int | float, set[int]]:
        """
        Function:

        - Implements Algorithm 2: Base Case of BMSSP

        Required Arguments:
        - upper_bound:
            - Type: int | float
        - frontier:
            - Type: set
            - What: Set with a single vertex x (complete)

        Returns:
        - new_upper_bound:
            - Type: int | float
            - What: The new upper bound for the search
        - new_frontier:
            - Type: set[int]
            - What: Set of vertices v such that distance_matrix[v] < new_upper_bound
        """
        assert len(frontier) == 1, "Frontier must be a singleton set"
        first_frontier = next(iter(frontier))

        new_frontier = set()
        heap = []
        heappush(heap, (self.distance_matrix[first_frontier], first_frontier))
        # Addition: Add visited check to prevent reprocessing and dropping into infinite loops
        visited = set()
        # grow until we exceed pivot_relaxation_steps (practical limit), as in Algorithm 2
        while heap and len(new_frontier) < self.pivot_relaxation_steps + 1:
            frontier_distance, frontier_idx = heappop(heap)
            if frontier_idx in visited:
                continue
            visited.add(frontier_idx)
            new_frontier.add(frontier_idx)
            for connection_idx, connection_distance in self.graph[
                frontier_idx
            ].items():
                new_distance = frontier_distance + connection_distance
                if (
                    new_distance <= self.distance_matrix[connection_idx]
                    and new_distance < upper_bound
                ):
                    # Addition: Add predecessor tracking
                    if new_distance < self.distance_matrix[connection_idx]:
                        self.predecessor[connection_idx] = frontier_idx
                        self.distance_matrix[connection_idx] = new_distance
                    heappush(heap, (new_distance, connection_idx))

        # If we exceeded k, trim by new boundary B' = max db over visited and return new_frontier = {db < B'}
        if len(new_frontier) > self.pivot_relaxation_steps:
            new_upper_bound = max(self.distance_matrix[i] for i in new_frontier)
            new_frontier = {
                i
                for i in new_frontier
                if self.distance_matrix[i] < new_upper_bound
            }
            return new_upper_bound, new_frontier
        else:
            # Success for this base case: return current upper_bound unchanged and the completed set
            return upper_bound, new_frontier

    def recursive_bmssp(
        self, recursion_depth: int, upper_bound: int | float, frontier: set[int]
    ) -> tuple[int | float, set[int]]:
        """
        Function:

        - Implements Algorithm 3: Bounded Multi-Source Shortest Path (BMSSP)

        Required Arguments:

        - recursion_depth:
            - Type: int
            - What: The depth of the recursion
        - upper_bound:
            - Type: float
            - What: The upper bound for the search
        - frontier:
            - Type: set[int]
            - What: The set of vertices to explore

        Returns:

        - new_upper_bound:
            - Type: int | float
            - What: The new upper bound for the search
        - new_frontier:
            - Type: set[int]
            - What: Set of vertices v such that distance_matrix[v] < new_upper_bound
        """
        # Base case
        if recursion_depth == 0:
            return self.base_case(upper_bound, frontier)

        # Step 4: Find pivots and temporary frontier
        pivots, temp_frontier = self.find_pivots(upper_bound, frontier)

        # Step 5–6: initialize data_struct with pivots
        # subset_size = 2^((l-1) * t)
        subset_size = 2 ** ((recursion_depth - 1) * self.target_tree_depth)
        data_struct = BmsspDataStructure(
            subset_size=subset_size, upper_bound=upper_bound
        )
        for pivot in pivots:
            data_struct.insert_key_value(pivot, self.distance_matrix[pivot])

        # Track new_frontier and B' according to Algorithm 3
        new_frontier = set()
        min_pivot_distance = min(
            (self.distance_matrix[p] for p in pivots), default=upper_bound
        )
        last_min_pivot_distance = min_pivot_distance

        # Work budget that scales with level: k^(2*l*t)
        # k = self.pivot_relaxation_steps
        # t = self.target_tree_depth
        work_budget = self.pivot_relaxation_steps ** (
            2 * recursion_depth * self.target_tree_depth
        )

        # Main loop
        while len(new_frontier) < work_budget and not data_struct.is_empty():
            # Step 10: Pull from data_struct: get data_struct_frontier_i and upper_bound_i
            data_struct_frontier_bound_i, data_struct_frontier_i = (
                data_struct.pull()
            )
            if not data_struct_frontier_i:
                # data_struct is empty -> success at this level
                break

            # Step 11: Recurse on (l-1, data_struct_frontier_bound_i, data_struct_frontier_i)
            last_min_pivot_distance_i, new_frontier_i = self.recursive_bmssp(
                recursion_depth - 1,
                data_struct_frontier_bound_i,
                data_struct_frontier_i,
            )

            # Track results
            new_frontier.update(new_frontier_i)
            last_min_pivot_distance = last_min_pivot_distance_i  # If we later stop due to budget, we must return the last_min_pivot_distance

            # Step 13: Initialize intermediate_frontier to batch-prepend
            intermediate_frontier = set()

            # Step 14–20: relax edges from new_frontier_i and enqueue into D or intermediate_frontier per their interval
            for new_frontier_idx in new_frontier_i:
                new_frontier_distance = self.distance_matrix[new_frontier_idx]
                for connection_idx, connection_distance in self.graph[
                    new_frontier_idx
                ].items():
                    # Addition: Avoid self-loops
                    if connection_idx == new_frontier_idx:
                        continue
                    new_distance = new_frontier_distance + connection_distance
                    if new_distance <= self.distance_matrix[connection_idx]:
                        # Addition: Add predecessor tracking
                        if new_distance < self.distance_matrix[connection_idx]:
                            self.predecessor[connection_idx] = new_frontier_idx
                            self.distance_matrix[connection_idx] = new_distance
                        # Insert based on which interval the new distance falls into
                        if (
                            data_struct_frontier_bound_i
                            <= new_distance
                            < upper_bound
                        ):
                            data_struct.insert_key_value(
                                connection_idx, new_distance
                            )
                        elif (
                            last_min_pivot_distance_i
                            <= new_distance
                            < data_struct_frontier_bound_i
                        ):
                            intermediate_frontier.add(
                                (connection_idx, new_distance)
                            )

            # Step 21: Batch prepend intermediate_frontier plus filtered data_struct_frontier_i in last_min_pivot_distance_i, data_struct_frontier_bound_i)
            data_struct_frontier_i_filtered = {
                (x, self.distance_matrix[x])
                for x in data_struct_frontier_i
                if last_min_pivot_distance_i
                <= self.distance_matrix[x]
                < data_struct_frontier_bound_i
            }
            for frontier_idx, frontier_distance in (
                intermediate_frontier | data_struct_frontier_i_filtered
            ):
                data_struct.insert_key_value(frontier_idx, frontier_distance)

        # Step 22: Final return
        return min(last_min_pivot_distance, upper_bound), new_frontier | {
            v
            for v in temp_frontier
            if self.distance_matrix[v] < last_min_pivot_distance
        }
